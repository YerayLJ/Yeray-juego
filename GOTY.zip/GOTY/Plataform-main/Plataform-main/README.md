# Plataform


Creditos:

Videos referencia:

            https://youtu.be/Qnbmb0uzmvE            
            https://www.youtube.com/watch?v=Sjmb52qFkJo

Imagen de TileMap: 
            Autor: Kenney. Kenney.nl or "www.kenney.nl from OpenGameArt.org            
            Titulo: Platformer Art Complete Pack            
            Licencia: CC0            
            Directorio en el proyecto: /Recursos/TileMap/preview.png            
            
            
